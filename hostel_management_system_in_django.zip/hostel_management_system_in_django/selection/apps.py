from django.apps import AppConfig


class SelectionConfig(AppConfig):
    name = 'selection'
    verbose_name = 'Hostel'
