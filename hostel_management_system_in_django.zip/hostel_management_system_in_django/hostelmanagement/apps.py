from django.apps import AppConfig


class HostelmanagementConfig(AppConfig):
    name = 'hostelmanagement'
